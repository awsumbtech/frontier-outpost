# CLAUDE.md - Frontier Outpost

## Project Identity

**Frontier Outpost** is a browser-based sci-fi RPG built with React (Vite). It features pause-and-plan auto-combat, squad management, deep gear/skill systems, a 20-mission story campaign across 5 chapters, and a consumable stim system.

## Tech Stack

- **Framework:** React 18 + Vite
- **Language:** JavaScript (JSX)
- **Styling:** CSS-in-JS (embedded styles), Rajdhani + Share Tech Mono fonts
- **State:** React useState/useEffect, persistent storage via localStorage
- **Build:** Vite dev server for local, static build for deploy
- **No backend.** All game logic runs client-side.

## Architecture

```
src/
  main.jsx              # Entry point
  App.jsx               # Root app, tab router, top bar
  styles/
    global.css          # All CSS (extracted from inline)
  data/
    classes.js          # CLASSES constant (4 classes, 2 branches, 6 skills each)
    missions.js         # MISSIONS array (20 missions, 5 chapters)
    story.js            # STORY_CHAPTERS (5 chapters, 15 beats)
    enemies.js          # ENEMY_TEMPLATES
    gear.js             # Weapon/armor/implant/gadget name pools, STIM_TYPES
    decisions.js        # DECISION_EVENTS for tactical pauses
    operativeNames.js   # OP_NAMES pool
    constants.js        # RARITY, RARITY_NAMES, RARITY_COLORS, CLASS_KEYS
  engine/
    combat.js           # combatRound(), generateEncounter()
    gear.js             # generateGear(), rollRarity()
    operatives.js       # createOperative(), getEffectiveStats(), xpForLevel()
    stims.js            # Stim application logic
    saves.js            # Save/load via localStorage
  components/
    tabs/
      SquadTab.jsx      # Squad list + operative detail view
      MissionTab.jsx    # Chapter-grouped mission select + active mission combat
      CommsTab.jsx      # Story transmissions
      InventoryTab.jsx  # Gear list + stim shop + stim usage
      RecruitTab.jsx    # Class recruit cards
    combat/
      CombatAlly.jsx    # Ally unit card during combat
      CombatEnemy.jsx   # Enemy unit card during combat
      CombatLog.jsx     # Scrolling combat log
      DecisionPanel.jsx # Tactical decision choices
      StickyBar.jsx     # Bottom action bar (Next Round, decisions, etc.)
    shared/
      ClassBadge.jsx    # Class affinity icon badge
      StatDiff.jsx      # Green/red stat comparison
      StatGrid.jsx      # Stat display grid
      BarDisplay.jsx    # HP/Shield/XP bar component
      GearSlot.jsx      # Equipment slot display
      Modal.jsx         # Reusable modal overlay
  hooks/
    useGameState.js     # Central game state hook with save/load
    useMission.js       # Mission lifecycle state machine
```

## Prime Directive Rules

1. **No scope creep.** Do not add features, systems, or mechanics not explicitly requested. If something seems like a good idea, propose it - don't build it.
2. **One thing at a time.** Complete the current task fully before starting the next. No partial implementations.
3. **Data stays in `/data`.** All game constants, templates, and configuration live in data files. Never hardcode game data in components.
4. **Engine stays pure.** Functions in `/engine` are pure (no React, no side effects). They take inputs and return outputs.
5. **Components are thin.** Components render UI and dispatch actions. Game logic lives in engine or hooks.
6. **Test combat math.** Any change to combat calculations must be verified with a before/after comparison on at least one scenario.
7. **Preserve save compatibility.** New fields in game state must have defaults so old saves don't crash. Use `game.field || defaultValue` patterns.
8. **No visual regressions.** After any UI change, verify the app renders correctly on both the Mission tab (during combat) and Squad tab (operative detail).

## Current State

The game is fully playable as a single-file artifact. The project init task is to decompose it into the architecture above while preserving all existing functionality.

## Commands

```bash
npm run dev     # Start dev server
npm run build   # Production build
npm run preview # Preview production build
```

## Key Design Decisions

- **Pause-and-plan combat:** Auto-combat runs round by round. Player clicks "Next Round" to advance. Tactical decisions interrupt every 3 rounds and between encounters.
- **Between-encounter healing:** Squad recovers 15% HP and 25% shields between encounters automatically.
- **Repeat penalty:** First mission clear gives full XP/credits. Repeats give 50% but full loot drops.
- **Chapter unlock:** Complete all 4 missions in a chapter to unlock the next.
- **Difficulty tags:** Missions show Easy/Fair/Hard/Brutal based on squad avg level vs recommended level.
- **Class-specific weapons only.** Armor, implants, and gadgets are universal (ANY tag).
- **6 skills per branch, 2 branches per class.** Skills have prerequisites (must learn in order within branch).
